/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

/**
 *
 * @author Asus
 */
public class Teacher extends Member {
    private String rank;
    Connection conn;
    public Teacher(Connection connection) {
        super(connection);
        conn = connection;
    }
    
    public void addDatanew(String username,String password) {
        try {
            Statement stmt = conn.createStatement();
            String sql = "select * from teacher s join member m on s.`Member_mem_id` = m.mem_id where first_name = '" + username + "'";
            ResultSet rs = stmt.executeQuery(sql);
            if (rs.next()) {
                if (password.equals(rs.getString("mem_id"))) {
                    setRank(rs.getString("rank"));
                }
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }

    }

    public String getRank() {
        return rank;
    }

    public void setRank(String rank) {
        this.rank = rank;
    }

    
}
