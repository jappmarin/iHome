/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

//import java.sql.Connection;
//import java.sql.ResultSet;
//import java.sql.SQLException;
//import java.sql.Statement;
//import java.util.LinkedList;
//import java.util.List;

/**
 *
 * @author Asus
 */
public class Media {
    private String media_id;
    private String media_name;
    private String director_name;
    private String type_media;
    private String soundtrack;
    private String status;
    private String description;
    private String count_disc;
    private String time_disc;
    private String actor;
    private String actress;
    private String subtitle;
    private String feel;
    private String more_feel;
    private String fee;
    private String check;
    private String media_photo;
    private String media_video;

    public Media() {}

    public String getMedia_id() {
        return media_id;
    }

    public void setMedia_id(String media_id) {
        this.media_id = media_id;
    }

    public String getMedia_name() {
        return media_name;
    }

    public void setMedia_name(String media_name) {
        this.media_name = media_name;
    }

    public String getDirector_name() {
        return director_name;
    }

    public void setDirector_name(String director_name) {
        this.director_name = director_name;
    }

    public String getType_media() {
        return type_media;
    }

    public void setType_media(String type_media) {
        this.type_media = type_media;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }
    
    public String getCheck() {
        return check;
    }

    public void setCheck(String check) {
        this.check = check;
    }

    public String getSoundtrack() {
        return soundtrack;
    }

    public void setSoundtrack(String soundtrack) {
        this.soundtrack = soundtrack;
    }
    public String getDescription() {
        return description;
    }
    public void setDescription(String description) {
        this.description = description;
    }
    public String getCount_disc() {
        return count_disc;
    }
    public void setCount_disc(String count_disc) {
        this.count_disc = count_disc;
    }
    public String getTime_disc() {
        return time_disc;
    }
    public void setTime_disc(String time_disc) {
        this.time_disc = time_disc;
    }
    public String getActor() {
        return actor;
    }
    public void setActor(String actor) {
        this.actor = actor;
    }
    public String getActress() {
        return actress;
    }
    public void setActress(String actress) {
        this.actress = actress;
    }
    public String getSubtitle() {
        return subtitle;
    }
    public void setSubtitle(String subtitle) {
        this.subtitle = subtitle;
    }
    public String getFeel() {
        return feel;
    }
    public void setFeel(String feel) {
        this.feel = feel;
    }
    public String getFee() {
        return fee;
    }
    public void setFee(String fee) {
        this.fee = fee;
    }
    public String getMore_feel() {
        return more_feel;
    }
    public void setMore_feel(String more_feel) {
        this.more_feel = more_feel;
    }

    public String getMedia_photo() {
        return media_photo;
    }

    public void setMedia_photo(String media_photo) {
        this.media_photo = media_photo;
    }

    public String getMedia_video() {
        return media_video;
    }

    public void setMedia_video(String media_video) {
        this.media_video = media_video;
    }
    
    
    
}
