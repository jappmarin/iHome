/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Asus
 */
public class Manage extends Media {

    private String actor_id;
    private String director_id;
    private String check_global;
    Connection conn;

    public Manage(Connection conn) {
        this.conn = conn;
    }

    public void Insert(String media_id, String media_name, String description, String count_disc, String time_disc, String director_id,
            String director_name, String actor_id, String actor, String actress, String lang_sound, String lang_sub, String type,
            String feel, String more_feel, String photo, String video) {
        try {
            Statement stmt = conn.createStatement();
            int cd = Integer.parseInt(count_disc);
            int td = Integer.parseInt(time_disc);
            Statement stmt_check = conn.createStatement();
            String sql_check = "SELECT * FROM actor where actor_id = '" + actor_id + "';";
            ResultSet rs_check = stmt_check.executeQuery(sql_check);
            if (!rs_check.next()) {
                String sql = "INSERT INTO db_media.actor (actor_id, actor, actress) \n"
                        + "	VALUES ('" + actor_id + "', '" + actor + "', '" + actress + "');";
                stmt.executeUpdate(sql);
            }
            sql_check = "SELECT * FROM director where director_id = '" + director_id + "';";
            rs_check = stmt_check.executeQuery(sql_check);
            if (!rs_check.next()) {
                String sql2 = "INSERT INTO db_media.director (director_id, director_name) \n"
                        + "	VALUES ('" + director_id + "', '" + director_name + "');";
                stmt.executeUpdate(sql2);
            }
            String sql3 = "INSERT INTO db_media.media_details (media_id, media_name, description, count_disc, time_disc, `Status_status_id`, `Type_media_type_id`, `Director_director_id`,media_photo,media_video) \n"
                    + "	VALUES ('" + media_id + "', '" + media_name + "', '" + description + "', " + cd + ", " + td + ", 'S01', '" + type + "', '" + director_id + "','" + photo + "','" + video + "');";
            String sql4 = "INSERT INTO db_media.show_by (`Media_details_media_id`, `Media_details_Type_media_type_id`, `Media_details_Director_director_id`, `Actor_actor_id`) \n"
                    + "	VALUES ('" + media_id + "', '" + type + "', '" + director_id + "', '" + actor_id + "');";
            String sql5 = "INSERT INTO db_media.soundtrack (`Media_details_media_id`, `Media_details_Type_media_type_id`, `Media_details_Director_director_id`, language_language_id) \n"
                    + "	VALUES ('" + media_id + "', '" + type + "', '" + director_id + "', '" + lang_sound + "');";
            String sql6 = "INSERT INTO db_media.subtitle (`Media_details_media_id`, `Media_details_Type_media_type_id`, `Media_details_Director_director_id`, language_language_id) \n"
                    + "	VALUES ('" + media_id + "', '" + type + "', '" + director_id + "', '" + lang_sub + "');";
            String sql7 = "INSERT INTO db_media.feel_media (`Media_details_media_id`, `Media_details_Type_media_type_id`, `Media_details_Director_director_id`, feel_of_media_feel_id, more_feel) \n"
                    + "	VALUES ('" + media_id + "', '" + type + "', '" + director_id + "', '" + feel + "', '" + more_feel + "');";
            stmt.executeUpdate(sql3);
            stmt.executeUpdate(sql4);
            stmt.executeUpdate(sql5);
            stmt.executeUpdate(sql6);
            stmt.executeUpdate(sql7);
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }

    public void Edit(String media_id_edit, String media_name, String description, String count_disc, String time_disc,
            String director_name, String actor, String actress, String lang_sound, String lang_sub,
            String feel, String more_feel, String photo, String video) {
        try {
            Statement stmt = conn.createStatement();

            if (!media_name.equals("-") && !media_name.equals("")) {
                String sql = "UPDATE media_details\n"
                        + "SET media_name = \"" + media_name + "\"\n"
                        + "WHERE media_id = \"" + media_id_edit + "\" ;";
                stmt.executeUpdate(sql);
                check_global = "5";
            }
            if (!description.equals("-") && !media_name.equals("")) {
                String sql = "UPDATE media_details\n"
                        + "SET description = \"" + description + "\"\n"
                        + "WHERE media_id = \"" + media_id_edit + "\" ;";
                stmt.executeUpdate(sql);
                check_global = "5";
            }
            if (!count_disc.equals("-") && !media_name.equals("")) {
                String sql = "UPDATE media_details\n"
                        + "SET count_disc = " + Integer.parseInt(count_disc) + "\n"
                        + "WHERE media_id = \"" + media_id_edit + "\" ;";
                stmt.executeUpdate(sql);
                check_global = "5";
            }
            if (!time_disc.equals("-") && !media_name.equals("")) {
                String sql = "UPDATE media_details\n"
                        + "SET time_disc = " + Integer.parseInt(time_disc) + "\n"
                        + "WHERE media_id = \"" + media_id_edit + "\" ;";
                stmt.executeUpdate(sql);
                check_global = "5";
            }
            if (!photo.equals("-") && !media_name.equals("")) {
                String sql = "UPDATE media_details\n"
                        + "SET media_photo = \"" + photo + "\"\n"
                        + "WHERE media_id = \"" + media_id_edit + "\" ;";
                stmt.executeUpdate(sql);
                check_global = "5";
            }
            if (!video.equals("-") && !media_name.equals("")) {
                String sql = "UPDATE media_details\n"
                        + "SET media_video = \"" + video + "\"\n"
                        + "WHERE media_id = \"" + media_id_edit + "\" ;";
                stmt.executeUpdate(sql);
                check_global = "5";
            }
            if (!director_name.equals("-") && !media_name.equals("")) {
                String sql0 = "SELECT * FROM show_by where Media_details_media_id = \"" + media_id_edit + "\";";
                ResultSet rs = stmt.executeQuery(sql0);
                rs.next();
                String d_id = rs.getString("Media_details_Director_director_id");
                String sql = "UPDATE director\n"
                        + "SET director_name = \"" + director_name + "\"\n"
                        + "WHERE director_id = \"" + d_id + "\";";
                stmt.executeUpdate(sql);
                check_global = "5";
            }
            if (!actor.equals("-") && !media_name.equals("")) {
                String sql0 = "SELECT * FROM show_by where Media_details_media_id = \"" + media_id_edit + "\";";
                ResultSet rs = stmt.executeQuery(sql0);
                rs.next();
                String ac_id = rs.getString("Actor_actor_id");
                String sql = "UPDATE actor\n"
                        + "SET actor = \"" + actor + "\"\n"
                        + "WHERE actor_id = \"" + ac_id + "\";";
                stmt.executeUpdate(sql);
                check_global = "5";
            }
            if (!actress.equals("-") && !media_name.equals("")) {
                String sql0 = "SELECT * FROM show_by where Media_details_media_id = \"" + media_id_edit + "\";";
                ResultSet rs = stmt.executeQuery(sql0);
                rs.next();
                String ac_id = rs.getString("Actor_actor_id");
                String sql = "UPDATE actor\n"
                        + "SET actress =  \"" + actress + "\"\n"
                        + "WHERE actor_id = \"" + ac_id + "\";";
                stmt.executeUpdate(sql);
                check_global = "5";
            }

            String sql_sound = "SELECT Media_details_media_id,language_language_id FROM soundtrack where Media_details_media_id = \"" + media_id_edit + "\";";
            ResultSet rs = stmt.executeQuery(sql_sound);
            if (rs.next()) {
                String sound_id = rs.getString("language_language_id");
                if (!lang_sound.equals(sound_id)) {
                    String sql = "UPDATE soundtrack\n"
                            + "SET language_language_id =  \"" + lang_sound + "\"\n"
                            + "WHERE Media_details_media_id = \"" + media_id_edit + "\";";
                    stmt.executeUpdate(sql);
                    check_global = "5";
                }
            }
            String sql_sub = "SELECT Media_details_media_id,language_language_id FROM soundtrack where Media_details_media_id = \"" + media_id_edit + "\";";
            rs = stmt.executeQuery(sql_sub);
            if (rs.next()) {
                if (!lang_sub.equals(rs.getString("language_language_id"))) {
                    String sql = "UPDATE subtitle\n"
                            + "SET language_language_id =  \"" + lang_sub + "\"\n"
                            + "WHERE Media_details_media_id = \"" + media_id_edit + "\";";
                    stmt.executeUpdate(sql);
                    check_global = "5";
                }
            }
            String sql_feel = "SELECT Media_details_media_id,feel_of_media_feel_id FROM feel_media where Media_details_media_id = \"" + media_id_edit + "\";";
            rs = stmt.executeQuery(sql_feel);
            if (rs.next()) {
                if (!feel.equals(rs.getString("feel_of_media_feel_id"))) {
                    String sql = "UPDATE feel_media\n"
                            + "SET feel_of_media_feel_id =  \"" + feel + "\"\n"
                            + "WHERE Media_details_media_id = \"" + media_id_edit + "\";";
                    stmt.executeUpdate(sql);
                    check_global = "5";
                }
            }
            String sql_mfeel = "SELECT Media_details_media_id,more_feel FROM feel_media where Media_details_media_id = \"" + media_id_edit + "\";";
            rs = stmt.executeQuery(sql_mfeel);
            if (rs.next()) {
                if (!more_feel.equals(rs.getString("more_feel"))) {
                    String sql = "UPDATE feel_media\n"
                            + "SET more_feel =  \"" + more_feel + "\"\n"
                            + "WHERE Media_details_media_id = \"" + media_id_edit + "\";";
                    stmt.executeUpdate(sql);
                    check_global = "5";
                }
            }
            if(!check_global.equals("5"))
                check_global = "4";
            
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }

    public void Show(String media_id, String media_name, String description, String count_disc, String time_disc, String director_id,
            String director_name, String actor_id, String actor, String actress, String lang_sound, String lang_sub, String type,
            String feel, String more_feel, String photo, String video) {
        try {
            Statement stmt = conn.createStatement();
            String sql = "select m.media_name,d.director_id,a.actor_id,l.language_name,la.language_name,type,fe.feel_name,feel.feel_name\n"
                    + "from media_details m \n"
                    + "join director d \n"
                    + "on m.`Director_director_id` = d.director_id\n"
                    + "join type_media t\n"
                    + "on m.`Type_media_type_id` = t.type_id\n"
                    + "join soundtrack s\n"
                    + "on s.`Media_details_media_id` = m.media_id\n"
                    + "join `language` l\n"
                    + "on l.language_id = s.language_language_id\n"
                    + "join subtitle sub\n"
                    + "on sub.`Media_details_media_id` = m.media_id\n"
                    + "join `language` la\n"
                    + "on la.language_id = sub.language_language_id\n"
                    + "join status st\n"
                    + "on st.status_id = m.`Status_status_id`\n"
                    + "join feel_media f\n"
                    + "on f.`Media_details_media_id` = m.media_id\n"
                    + "join feel_of_media fe\n"
                    + "on fe.feel_id = f.feel_of_media_feel_id\n"
                    + "join feel_of_media feel\n"
                    + "on feel.feel_id = f.more_feel\n"
                    + "join show_by sh\n"
                    + "on sh.`Media_details_media_id` = m.media_id\n"
                    + "join actor a\n"
                    + "on a.actor_id = sh.`Actor_actor_id`\n"
                    + "where media_id = \'" + media_id + "\';";
            ResultSet rs = stmt.executeQuery(sql);
            if (rs.next()) {
                if (!media_name.equals(rs.getString("m.media_name")) || !director_id.equals(rs.getString("d.director_id")) || !actor_id.equals(rs.getString("a.actor_id"))) {
                    check_global = "0";
                } else {
                    setMedia_id(media_id);
                    setMedia_name(media_name);
                    setDescription(description);
                    setCount_disc(count_disc);
                    setTime_disc(time_disc);
                    setDirector_name(director_name);
                    setActor(actor);
                    setActress(actress);
                    setSoundtrack(rs.getString("l.language_name"));
                    setSubtitle(rs.getString("la.language_name"));
                    setType_media(rs.getString("type"));
                    setFeel(rs.getString("fe.feel_name"));
                    setMore_feel(rs.getString("feel.feel_name"));
                    setMedia_photo(photo);
                    setMedia_video(video);
                    this.actor_id = actor_id;
                    this.director_id = director_id;
                    check_global = "1";
                }
            } else {
                check_global = "0";
            }

        } catch (SQLException ex) {
            Logger.getLogger(Manage.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public void Delete(String media_id) {
        try {
            Statement stmt = conn.createStatement();
            String sql = "SELECT Media_details_media_id,Actor_actor_id,Media_details_Director_director_id FROM show_by where Media_details_media_id = \"" + media_id + "\";";
            ResultSet rs = stmt.executeQuery(sql);
            if (rs.next()) {
                String ac_id = rs.getString("Actor_actor_id");
                String d_id = rs.getString("Media_details_Director_director_id");
                String sql1 = "DELETE FROM db_media.soundtrack WHERE Media_details_media_id = \"" + media_id + "\";";
                String sql2 = "DELETE FROM db_media.subtitle WHERE Media_details_media_id = \"" + media_id + "\";";
                String sql3 = "DELETE FROM db_media.feel_media WHERE Media_details_media_id = \"" + media_id + "\";";
                String sql4 = "DELETE FROM db_media.show_by WHERE Media_details_media_id = \"" + media_id + "\";";
                String sql5 = "DELETE FROM db_media.media_details WHERE media_id = \"" + media_id + "\";";
                Statement stmt_check = conn.createStatement();
                String sql_check = "SELECT * FROM show_by where Actor_actor_id = '" + ac_id + "';";
                ResultSet rs_check = stmt_check.executeQuery(sql_check);
                int count = 0;
                while (rs_check.next()) {
                    count++;
                }
                if (count == 1 && !ac_id.equals("AC015")) {
                    String sql6 = "DELETE FROM db_media.actor WHERE actor_id = \"" + ac_id + "\";";
                    stmt.executeUpdate(sql6);
                }
                sql_check = "SELECT * FROM show_by where Media_details_Director_director_id = '" + d_id + "';";
                rs_check = stmt_check.executeQuery(sql_check);
                count = 0;
                while (rs_check.next()) {
                    count++;
                }
                if (count == 1) {
                    String sql7 = "DELETE FROM db_media.director WHERE director_id = \"" + d_id + "\";";
                    stmt.executeUpdate(sql7);
                }
                stmt.executeUpdate(sql1);
                stmt.executeUpdate(sql2);
                stmt.executeUpdate(sql3);
                stmt.executeUpdate(sql4);
                stmt.executeUpdate(sql5);
                check_global = "3";
            } else {
                check_global = "2";
            }

        } catch (SQLException ex) {
            Logger.getLogger(Manage.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public String getActor_id() {
        return actor_id;
    }

    public void setActor_id(String actor_id) {
        this.actor_id = actor_id;
    }

    public String getDirector_id() {
        return director_id;
    }

    public void setDirector_id(String director_id) {
        this.director_id = director_id;
    }

    public String getCheck_global() {
        return check_global;
    }

    public void setCheck_global(String check_global) {
        this.check_global = check_global;
    }

}
