/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

/**
 *
 * @author Asus
 */
public class Member {

    private String mem_id;
    private String first_name;
    private String last_name;
    private String email;
    private String phone;
    private String facaulty;

    Connection conn;

    public Member(Connection connection) {
        conn = connection;
    }

    public void addData(String username, String password) {
        try {
            Statement stmt = conn.createStatement();
            String sql = "SELECT * from member where first_name='" + username + "'";
            ResultSet rs = stmt.executeQuery(sql);
            if (rs.next()) {
                if (password.equals(rs.getString("mem_id"))) {
                    mem_id = (rs.getString("mem_id"));
                    first_name = (rs.getString("first_name"));
                    last_name = (rs.getString("last_name"));
                    email = (rs.getString("email"));
                    phone = (rs.getString("phone"));
                    facaulty = (rs.getString("facaulty"));
                }
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }

    }

    public String getMem_id() {
        return mem_id;
    }

    public void setMem_id(String mem_id) {
        this.mem_id = mem_id;
    }

    public String getFirst_name() {
        return first_name;
    }

    public void setFirst_name(String first_name) {
        this.first_name = first_name;
    }

    public String getLast_name() {
        return last_name;
    }

    public void setLast_name(String last_name) {
        this.last_name = last_name;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getFacaulty() {
        return facaulty;
    }

    public void setFacaulty(String facaulty) {
        this.facaulty = facaulty;
    }

    

}
