/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.LinkedList;
import java.util.List;

/**
 *
 * @author Asus
 */
public class Viewmedia extends Media {

    List <Media> media_bookings;
    Connection conn;

    public void viewmedia() {
    }

    public void addItem(String media_name) {
        try {
            Statement stmt = conn.createStatement();
            String sql = "select media_id,media_name,description,count_disc,time_disc,media_photo,director_name,actor,actress,status,l.language_name,la.language_name,type,fe.feel_name,feel.feel_name,fee_per_day\n"
                    + "                    from media_details m \n"
                    + "                    join director d \n"
                    + "                    on m.`Director_director_id` = d.director_id\n"
                    + "                    join type_media t\n"
                    + "                    on m.`Type_media_type_id` = t.type_id\n"
                    + "                    join soundtrack s\n"
                    + "                    on s.`Media_details_media_id` = m.media_id\n"
                    + "                    join `language` l\n"
                    + "                    on l.language_id = s.language_language_id\n"
                    + "                    join subtitle sub\n"
                    + "                    on sub.`Media_details_media_id` = m.media_id\n"
                    + "                    join `language` la\n"
                    + "                    on la.language_id = sub.language_language_id\n"
                    + "                    join status st\n"
                    + "                    on st.status_id = m.`Status_status_id`\n"
                    + "                    join feel_media f\n"
                    + "                    on f.`Media_details_media_id` = m.media_id\n"
                    + "                    join feel_of_media fe\n"
                    + "                    on fe.feel_id = f.feel_of_media_feel_id\n"
                    + "                    join feel_of_media feel\n"
                    + "                    on feel.feel_id = f.more_feel\n"
                    + "                    join show_by sh\n"
                    + "                    on sh.`Media_details_media_id` = m.media_id\n"
                    + "                    join actor a\n"
                    + "                    on a.actor_id = sh.`Actor_actor_id`\n"
                    + "                    where media_name like \"" + media_name + "\";";
            ResultSet rs = stmt.executeQuery(sql);
            while (rs.next()) {
                Media m = new Media();
                m.setMedia_id(rs.getString("media_id"));
                m.setStatus(rs.getString("status"));
                media_bookings.add(m);
                setMedia_name(rs.getString("media_name"));
                setDirector_name(rs.getString("director_name"));
                setDescription(rs.getString("description"));
                setCount_disc(rs.getString("count_disc"));
                setTime_disc(rs.getString("time_disc"));
                setMedia_photo(rs.getString("media_photo"));
                setActor(rs.getString("actor"));
                setActress(rs.getString("actress"));
                setSoundtrack(rs.getString("l.language_name"));
                setSubtitle(rs.getString("la.language_name"));
                setType_media(rs.getString("type"));
                setFeel(rs.getString("fe.feel_name"));
                setMore_feel(rs.getString("feel.feel_name"));
                setFee(rs.getString("fee_per_day"));
            }

        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }

    public List<Media> getMedia_bookings() {
        return media_bookings;
    }

    public Viewmedia(Connection conn) {
        this.conn = conn;
        media_bookings = new LinkedList<Media>();
    }


}
