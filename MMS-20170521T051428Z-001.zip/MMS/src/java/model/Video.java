/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

/**
 *
 * @author Asus
 */
public class Video {
    private String media_name;
    private String media_video;
    Connection conn;
     public Video(Connection conn) {
        this.conn = conn;
    }
     public void addVideo(String media_id){
         try {
            Statement stmt = conn.createStatement();
            String sql = "select media_name,media_video from media_details where media_id = '"+media_id+"';";
            ResultSet rs = stmt.executeQuery(sql);
            rs.next();
            media_name = rs.getString("media_name");
            media_video = rs.getString("media_video");
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
     }

    public String getMedia_name() {
        return media_name;
    }

    public void setMedia_name(String media_name) {
        this.media_name = media_name;
    }

    public String getMedia_video() {
        return media_video;
    }

    public void setMedia_video(String media_video) {
        this.media_video = media_video;
    }
     
}
