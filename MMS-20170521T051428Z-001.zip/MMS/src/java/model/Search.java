/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.LinkedList;
import java.util.List;

/**
 *
 * @author Asus
 */
public class Search {

    List <Media> medias;
    Connection conn;
    private String check="0";

    public void search() {}

    public void addItem(String cmd, String text) {
        try {
            Statement stmt = conn.createStatement();
            String sql = "select m.media_id,m.media_name,d.director_name,t.`type`,st.status,language_name\n"
                    + "from media_details m \n"
                    + "join director d \n"
                    + "on m.`Director_director_id` = d.director_id\n"
                    + "join type_media t\n"
                    + "on m.`Type_media_type_id` = t.type_id\n"
                    + "join soundtrack s\n"
                    + "on s.`Media_details_media_id` = m.media_id\n"
                    + "join `language` l\n"
                    + "on l.language_id = s.language_language_id\n"
                    + "join status st\n"
                    + "on st.status_id = m.`Status_status_id`\n"
                    + "where " + cmd + " like \"%" + text + "%\";\n"
                    + "";
            ResultSet rs = stmt.executeQuery(sql);
            while (rs.next()) {
                Media m = new Media();
                m.setMedia_id(rs.getString("media_id"));
                m.setMedia_name(rs.getString("media_name"));
                m.setDirector_name(rs.getString("director_name"));
                m.setType_media(rs.getString("type"));
                m.setSoundtrack(rs.getString("language_name"));
                m.setStatus(rs.getString("status"));
                medias.add(m);
                setCheck("1");
            }

        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }
    public List<Media> getMedias(){
        return medias;
    }

    public Search(Connection conn) {
        this.conn = conn;
        medias = new LinkedList<Media>();
    }

    public String getCheck() {
        return check;
    }

    public void setCheck(String check) {
        this.check = check;
    }
    

}
