/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.LinkedList;
import java.util.List;

/**
 *
 * @author Asus
 */
public class Loanreturn {

    List<Loanreturn> fees;
    List<Loanreturn> feest;
    List<Loanreturn> feet;
    private String mem;
    private String fname;
    private String lname;
    private String media;
    private int day_loan;
    private int month_loan;
    private int year_loan;
    private int sd_return;
    private int sm_return;
    private int sy_return;
    private int td_return;
    private int tm_return;
    private int ty_return;
    private String check = "f";
    private int count = 0;
    private int fee;
    Connection conn;

    public Loanreturn() {
    }

    public List<Loanreturn> getFees() {
        return fees;
    }

    public List<Loanreturn> getFeest() {
        return feest;
    }

    public List<Loanreturn> getFeet() {
        return feet;
    }

    public Loanreturn(Connection conn) {
        this.conn = conn;
        fees = new LinkedList<Loanreturn>();
        feest = new LinkedList<Loanreturn>();
        feet = new LinkedList<Loanreturn>();
    }

    public void addLoan(String mem_id, String media_id, String libra_id) {
        try {
            Statement stmt = conn.createStatement();
            Statement stmt_cm = conn.createStatement();
            String cm = "SELECT mem_id FROM member ;";

            ResultSet rs_cm = stmt_cm.executeQuery(cm);
            String c = "n";
            while (rs_cm.next()) {
                if (mem_id.equals(rs_cm.getString("mem_id"))) {
                    c = "y";
                }
            }

            String cc = "SELECT Member_mem_id FROM loan_return l where Member_mem_id = '" + mem_id + "';";
            ResultSet rs_cc = stmt.executeQuery(cc);
            while (rs_cc.next()) {
                count += 1;
            }
            Statement stmt_b = conn.createStatement();
            String sql_b = "SELECT *\n"
                    + "FROM booking b\n"
                    + "join list_booking lb\n"
                    + "on b.booking_id = lb.`Booking_booking_id`\n"
                    + "where Member_mem_id = '" + mem_id + "'\n"
                    + "and Media_details_media_id = '" + media_id + "';";
            ResultSet rs_b = stmt_b.executeQuery(sql_b);
            if (rs_b.next()) {
                String b = rs_b.getString("booking_id");
                String lb = rs_b.getString("listbooking_id");
                Statement stmt_lb = conn.createStatement();
                String sql_lb = "DELETE FROM db_media.list_booking WHERE listbooking_id = \"" + lb + "\";";
                stmt_lb.executeUpdate(sql_lb);
                sql_lb = "DELETE FROM db_media.booking WHERE booking_id = \"" + b + "\";";
                stmt_lb.executeUpdate(sql_lb);
            }
            String sql = "SELECT * FROM media_details where Status_status_id = 'S01' or Status_status_id = 'S04';";
            ResultSet rs = stmt.executeQuery(sql);
            while (rs.next() && c.equals("y")) {
                if (media_id.equals(rs.getString("media_id"))) {
                    if (mem_id.charAt(0) == '5' && count <= 3) {
                        Statement stmt_s = conn.createStatement();
                        String sql_s = "INSERT INTO db_media.loan_return (lr_id, loan_day, return_day, `Member_mem_id`, `Member_Condition_borrow_con_id`, `Librarian_libra_id`) \n"
                                + "	VALUES ('L0" + media_id + "', '" + getYear_loan() + "-" + getMonth_loan() + "-" + getDay_loan() + "', '" + getSy_return() + "-" + getSm_return() + "-" + getSd_return() + "', '" + mem_id + "', '0001', '" + libra_id + "')\n"
                                + "";
                        stmt_s.executeUpdate(sql_s);
                        count += 1;
                        setCheck("s");
                    } else if (mem_id.charAt(0) == '9' && count <= 6) {
                        Statement stmt_t = conn.createStatement();
                        String sql_t = "INSERT INTO db_media.loan_return (lr_id, loan_day, return_day, `Member_mem_id`, `Member_Condition_borrow_con_id`, `Librarian_libra_id`) \n"
                                + "	VALUES ('L0" + media_id + "', '" + getYear_loan() + "-" + getMonth_loan() + "-" + getDay_loan() + "', '" + getTy_return() + "-" + getTm_return() + "-" + getTd_return() + "', '" + mem_id + "', '0002', '" + libra_id + "')\n"
                                + "";
                        stmt_t.executeUpdate(sql_t);
                        count += 1;
                        setCheck("t");
                    }
                    Statement stmt_list = conn.createStatement();
                    String sql_l = "INSERT INTO db_media.list_loan_return (listlr_id, `Loan_Return_lr_id`, `Media_details_media_id`) \n"
                            + "	VALUES ('LL" + media_id + "', 'L0" + media_id + "', '" + media_id + "')\n"
                            + "";
                    stmt_list.executeUpdate(sql_l);
                    sql_l = "UPDATE media_details SET Status_status_id = 'S02' WHERE media_id = '" + media_id + "';";
                    stmt_list.executeUpdate(sql_l);
                }
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }

    public void addBorrow(String media_id, String mem_id) {
        try {
            int day = day_loan;
            int month = month_loan;
            int year = year_loan;
            Statement stmt = conn.createStatement();
            String sql = "SELECT l.lr_id,l.return_day,llr.`Media_details_media_id`,l.`Member_mem_id` FROM loan_return l \n"
                    + "join list_loan_return llr \n"
                    + "on l.lr_id = llr.`Loan_Return_lr_id`\n"
                    + "where Member_mem_id = '" + mem_id + "'\n"
                    + "and Media_details_media_id = '" + media_id + "';";
            ResultSet rs = stmt.executeQuery(sql);
            rs.next();
            String lr_id = rs.getString("l.lr_id");
            String[] date = rs.getString("l.return_day").split("-");
            int day_re = Integer.parseInt(date[2]);
            int month_re = Integer.parseInt(date[1]);
            int year_re = Integer.parseInt(date[0]);
            if (year <= year_re) {
                if (month <= month_re) {
                    if (day_re - 3 < day && day <= day_re) {
                        if (mem_id.charAt(0) == '5') {
                            day_re += 7;
                        } else if (mem_id.charAt(0) == '9') {
                            day_re += 10;
                        }
                        if (month_re == 1 || month_re == 3 || month_re == 5 || month_re == 7 || month_re == 8 || month_re == 10 || month_re == 12) {
                            if (day_re > 31) {
                                day_re -= 31;
                                month_re += 1;
                                if (month_re > 12) {
                                    month_re -= 12;
                                    year_re += 1;
                                }
                            }
                        } else {
                            if (day_re > 30) {
                                day_re -= 30;
                                month_re += 1;
                                if (month_re > 12) {
                                    month_re -= 12;
                                    year_re += 1;
                                }
                            }
                        }

                        String return_day = Integer.toString(year_re) + "-" + Integer.toString(month_re) + "-" + Integer.toString(day_re);
                        String loan_day = Integer.toString(year) + "-" + Integer.toString(month) + "-" + Integer.toString(day);
                        Statement stmt_1 = conn.createStatement();
                        String sql_1 = "UPDATE loan_return SET return_day = '" + return_day + "' WHERE lr_id = '" + lr_id + "';";
                        stmt_1.executeUpdate(sql_1);
                        sql_1 = "UPDATE loan_return SET loan_day = '" + loan_day + "' WHERE lr_id = '" + lr_id + "';";
                        stmt_1.executeUpdate(sql_1);
                        check = "p";
                        mem = mem_id;
                        media = media_id;
                        sd_return = day_re;
                        sm_return = month_re;
                        sy_return = year_re;
                    }
                }
            }

        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }

    public void showLoan(String mem_id) {
        try {
            int day = day_loan;
            int month = month_loan;
            int year = year_loan;
            Statement stmt = conn.createStatement();
            String sql = "SELECT media_id,media_name,loan_day,return_day\n"
                    + "FROM loan_return l \n"
                    + "join member m \n"
                    + "on l.`Member_mem_id`=m.mem_id\n"
                    + "join list_loan_return llr\n"
                    + "on l.lr_id = llr.`Loan_Return_lr_id`\n"
                    + "join media_details md\n"
                    + "on md.media_id = llr.`Media_details_media_id`\n"
                    + "where mem_id = '" + mem_id + "';";
            ResultSet rs = stmt.executeQuery(sql);
            while (rs.next()) {
                String[] date = rs.getString("return_day").split("-");
                int day_re = Integer.parseInt(date[2]);
                int month_re = Integer.parseInt(date[1]);
                int year_re = Integer.parseInt(date[0]);
                Statement stmt_fee = conn.createStatement();
                String sql_fee = "SELECT media_id,fee_per_day FROM media_details m join type_media t on m.`Type_media_type_id`=t.type_id where media_id = media_id;";
                ResultSet rs_fee = stmt_fee.executeQuery(sql_fee);
                rs_fee.next();
                int fee_media = rs_fee.getInt("fee_per_day");
                if (year <= year_re) {
                    if (month <= month_re) {
                        if (day <= day_re) {
                            fee = 0;
                        } else {
                            if (day - day_re >= 10) {
                                fee = fee_media * 10;
                            } else {
                                fee = fee_media * (day - day_re);
                            }
                        }
                    } else if (month - month_re >= 2) {
                        fee = fee_media * 10;
                    } else if (month - month_re == 1) {
                        if (month == 1 || month == 3 || month == 5 || month == 7 || month == 8 || month == 10 || month == 12) {
                            day += (31 - day_re + 1);
                            if (day - day_re >= 10) {
                                fee = fee_media * 10;
                            } else {
                                fee = fee_media * (day - day_re);
                            }
                        } else {
                            day += (30 - day_re + 1);
                            if (day - day_re >= 10) {
                                fee = fee_media * 10;
                            } else {
                                fee = fee_media * (day - day_re);
                            }
                        }
                    }
                } else if (year - year_re >= 2) {
                    fee = fee_media * 10;
                } else if (year - year_re == 1) {
                    month += 12;
                    if (month - month_re >= 2) {
                        fee = fee_media * 10;
                    } else if (month - month_re == 1) {
                        if (month == 1 || month == 3 || month == 5 || month == 7 || month == 8 || month == 10 || month == 12) {
                            day += (31 - day_re + 1);
                            if (day - day_re >= 10) {
                                fee = fee_media * 10;
                            } else {
                                fee = fee_media * (day - day_re);
                            }
                        } else {
                            day += (30 - day_re + 1);
                            if (day - day_re >= 10) {
                                fee = fee_media * 10;
                            } else {
                                fee = fee_media * (day - day_re);
                            }
                        }
                    }
                }
                String[] date_l = rs.getString("loan_day").split("-");
                String[] date_r = rs.getString("return_day").split("-");
                Loanreturn f = new Loanreturn();
                f.setMem(rs.getString("media_id"));
                f.setMedia(rs.getString("media_name"));
                f.setFname(date_l[2] + "/" + date_l[1] + "/" + date_l[0]);
                f.setLname(date_r[2] + "/" + date_r[1] + "/" + date_r[0]);
                f.setFee(fee);
                fees.add(f);
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }

    public void viewFee() {
        try {
            Statement stmt = conn.createStatement();
            String sql = "SELECT mem_id,first_name,last_name,return_day,media_name,media_id \n"
                    + "FROM loan_return l \n"
                    + "join member m \n"
                    + "on l.`Member_mem_id`=m.mem_id\n"
                    + "join list_loan_return llr\n"
                    + "on l.lr_id = llr.`Loan_Return_lr_id`\n"
                    + "join media_details md\n"
                    + "on md.media_id = llr.`Media_details_media_id`;";
            ResultSet rs = stmt.executeQuery(sql);
            while (rs.next()) {
                int day = day_loan;
                int month = month_loan;
                int year = year_loan;
                String[] date = rs.getString("return_day").split("-");
                String media_name = rs.getString("media_name");
                int day_re = Integer.parseInt(date[2]);
                int month_re = Integer.parseInt(date[1]);
                int year_re = Integer.parseInt(date[0]);
                Statement stmt_fee = conn.createStatement();
                String sql_fee = "SELECT m.media_id,t.fee_per_day \n"
                        + "FROM media_details m \n"
                        + "join type_media t \n"
                        + "on m.`Type_media_type_id`=t.type_id \n"
                        + "where m.media_id = '" + rs.getString("media_id") + "';";
                ResultSet rs_fee = stmt_fee.executeQuery(sql_fee);
                rs_fee.next();
                int fee_media = rs_fee.getInt("fee_per_day");
                if (year <= year_re) {
                    if (month <= month_re) {
                        if (day <= day_re) {
                            fee = 0;
                        } else {
                            if (day - day_re >= 10) {
                                fee = fee_media * 10;
                            } else {
                                fee = fee_media * (day - day_re);
                            }
                        }
                    } else if (month - month_re >= 2) {
                        fee = fee_media * 10;
                    } else if (month - month_re == 1) {
                        if (month == 1 || month == 3 || month == 5 || month == 7 || month == 8 || month == 10 || month == 12) {
                            day += (31 - day_re + 1);
                            if (day - day_re >= 10) {
                                fee = fee_media * 10;
                            } else {
                                fee = fee_media * (day - day_re);
                            }
                        } else {
                            day += (30 - day_re + 1);
                            if (day - day_re >= 10) {
                                fee = fee_media * 10;
                            } else {
                                fee = fee_media * (day - day_re);
                            }
                        }
                    }
                } else if (year - year_re >= 2) {
                    fee = fee_media * 10;
                } else if (year - year_re == 1) {
                    month += 12;
                    if (month - month_re >= 2) {
                        fee = fee_media * 10;
                    } else if (month - month_re == 1) {
                        if (month == 1 || month == 3 || month == 5 || month == 7 || month == 8 || month == 10 || month == 12) {
                            day += (31 - day_re + 1);
                            if (day - day_re >= 10) {
                                fee = fee_media * 10;
                            } else {
                                fee = fee_media * (day - day_re);
                            }
                        } else {
                            day += (30 - day_re + 1);
                            if (day - day_re >= 10) {
                                fee = fee_media * 10;
                            } else {
                                fee = fee_media * (day - day_re);
                            }
                        }
                    }
                }

                Loanreturn f = new Loanreturn();
                f.setMem(rs.getString("mem_id"));
                f.setFname(rs.getString("first_name"));
                f.setLname(rs.getString("last_name"));
                f.setMedia(media_name);
                f.setFee(fee);
                if (rs.getString("mem_id").charAt(0) == '5') {
                    feest.add(f);
                } else if (rs.getString("mem_id").charAt(0) == '9') {
                    feet.add(f);
                }
                fees.add(f);
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }

    public void reMedia(String mem_id, String media_id) {
        try {
            int day = day_loan;
            int month = month_loan;
            int year = year_loan;
            Statement stmt = conn.createStatement();
            String sql = "SELECT lr_id,return_day,Member_mem_id,Media_details_media_id \n"
                    + "FROM loan_return lr \n"
                    + "join list_loan_return l \n"
                    + "on lr.lr_id = l.`Loan_Return_lr_id` \n"
                    + "where Member_mem_id = '" + mem_id + "' \n"
                    + "and Media_details_media_id = '" + media_id + "';";
            ResultSet rs = stmt.executeQuery(sql);
            if (rs.next()) {
                String lr_id = rs.getString("lr_id");
                String[] date = rs.getString("return_day").split("-");
                int day_re = Integer.parseInt(date[2]);
                int month_re = Integer.parseInt(date[1]);
                int year_re = Integer.parseInt(date[0]);
                sql = "SELECT media_id,fee_per_day FROM media_details m join type_media t on m.`Type_media_type_id`=t.type_id where media_id = '" + media_id + "';";
                rs = stmt.executeQuery(sql);
                rs.next();
                int fee_media = rs.getInt("fee_per_day");
                if (year <= year_re) {
                    if (month <= month_re) {
                        if (day <= day_re) {
                            fee = 0;
                        } else {
                            if (day - day_re >= 10) {
                                fee = fee_media * 10;
                            } else {
                                fee = fee_media * (day - day_re);
                            }
                        }
                    } else if (month - month_re >= 2) {
                        fee = fee_media * 10;
                    } else if (month - month_re == 1) {
                        if (month == 1 || month == 3 || month == 5 || month == 7 || month == 8 || month == 10 || month == 12) {
                            day += (31 - day_re + 1);
                            if (day - day_re >= 10) {
                                fee = fee_media * 10;
                            } else {
                                fee = fee_media * (day - day_re);
                            }
                        } else {
                            day += (30 - day_re + 1);
                            if (day - day_re >= 10) {
                                fee = fee_media * 10;
                            } else {
                                fee = fee_media * (day - day_re);
                            }
                        }
                    }
                } else if (year - year_re >= 2) {
                    fee = fee_media * 10;
                } else if (year - year_re == 1) {
                    month += 12;
                    if (month - month_re >= 2) {
                        fee = fee_media * 10;
                    } else if (month - month_re == 1) {
                        if (month == 1 || month == 3 || month == 5 || month == 7 || month == 8 || month == 10 || month == 12) {
                            day += (31 - day_re + 1);
                            if (day - day_re >= 10) {
                                fee = fee_media * 10;
                            } else {
                                fee = fee_media * (day - day_re);
                            }
                        } else {
                            day += (30 - day_re + 1);
                            if (day - day_re >= 10) {
                                fee = fee_media * 10;
                            } else {
                                fee = fee_media * (day - day_re);
                            }
                        }
                    }
                }
                sd_return = day_re;
                sm_return = month_re;
                sy_return = year_re;
                Statement stmt_1 = conn.createStatement();
                String sql_1 = "UPDATE media_details SET Status_status_id = 'S01' WHERE media_id = '" + media_id + "';";
                stmt_1.executeUpdate(sql_1);
                sql_1 = "DELETE FROM db_media.list_loan_return WHERE Media_details_media_id = \"" + media_id + "\";";
                stmt_1.executeUpdate(sql_1);
                sql_1 = "DELETE FROM db_media.loan_return WHERE lr_id = \"" + lr_id + "\";";
                stmt_1.executeUpdate(sql_1);
                String cc = "SELECT Member_mem_id FROM loan_return l where Member_mem_id = '" + mem_id + "';";
                ResultSet rs_cc = stmt.executeQuery(cc);
                while (rs_cc.next()) {
                    count += 1;
                }
                if (mem_id.charAt(0) == '9') {
                    setCheck("t");
                } else if (mem_id.charAt(0) == '5') {
                    setCheck("s");
                }
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }

    public void addDate() {
        int day_l;
        int month_l;
        int year_l;
        int day_s;
        int month_s;
        int year_s;
        int day_t;
        int month_t;
        int year_t;
        GregorianCalendar gcalendar = new GregorianCalendar();
        day_l = gcalendar.get(Calendar.DATE);
        month_l = gcalendar.get(Calendar.MONTH) + 1;
        year_l = gcalendar.get(Calendar.YEAR);
        if (month_l == 1 || month_l == 3 || month_l == 5 || month_l == 7 || month_l == 8 || month_l == 10 || month_l == 12) {
            day_s = gcalendar.get(Calendar.DATE) + 7;
            month_s = gcalendar.get(Calendar.MONTH) + 1;
            year_s = gcalendar.get(Calendar.YEAR);
            if (day_s > 31) {
                day_s -= 31;
                month_s += 1;
                if (month_s > 12) {
                    month_s = 1;
                    year_s += 1;
                }
            }
            day_t = gcalendar.get(Calendar.DATE) + 10;
            month_t = gcalendar.get(Calendar.MONTH) + 1;
            year_t = gcalendar.get(Calendar.YEAR);
            if (day_t > 31) {
                day_t -= 31;
                month_t += 1;
                if (month_t > 12) {
                    month_t = 1;
                    year_t += 1;
                }
            }
        } else {
            day_s = gcalendar.get(Calendar.DATE) + 7;
            month_s = gcalendar.get(Calendar.MONTH) + 1;
            year_s = gcalendar.get(Calendar.YEAR);
            if (day_s > 30) {
                day_s -= 30;
                month_s += 1;
                if (month_s > 12) {
                    month_s = 1;
                    year_s += 1;
                }
            }
            day_t = gcalendar.get(Calendar.DATE) + 10;
            month_t = gcalendar.get(Calendar.MONTH) + 1;
            year_t = gcalendar.get(Calendar.YEAR);
            if (day_t > 30) {
                day_t -= 30;
                month_t += 1;
                if (month_t > 12) {
                    month_t = 1;
                    year_t += 1;
                }
            }
        }
        day_loan = day_l;
        month_loan = month_l;
        year_loan = year_l;
        System.out.println("day_l :" + day_loan);
        sd_return = day_s;
        sm_return = month_s;
        sy_return = year_s;
        td_return = day_t;
        tm_return = month_t;
        ty_return = year_t;
    }

    public int getDay_loan() {
        return day_loan;
    }

    public void setDay_loan(int day_loan) {
        this.day_loan = day_loan;
    }

    public int getMonth_loan() {
        return month_loan;
    }

    public void setMonth_loan(int month_loan) {
        this.month_loan = month_loan;
    }

    public int getYear_loan() {
        return year_loan;
    }

    public void setYear_loan(int year_loan) {
        this.year_loan = year_loan;
    }

    public int getSd_return() {
        return sd_return;
    }

    public void setSd_return(int sd_return) {
        this.sd_return = sd_return;
    }

    public int getSm_return() {
        return sm_return;
    }

    public void setSm_return(int sm_return) {
        this.sm_return = sm_return;
    }

    public int getSy_return() {
        return sy_return;
    }

    public void setSy_return(int sy_return) {
        this.sy_return = sy_return;
    }

    public int getTd_return() {
        return td_return;
    }

    public void setTd_return(int td_return) {
        this.td_return = td_return;
    }

    public int getTm_return() {
        return tm_return;
    }

    public void setTm_return(int tm_return) {
        this.tm_return = tm_return;
    }

    public int getTy_return() {
        return ty_return;
    }

    public void setTy_return(int ty_return) {
        this.ty_return = ty_return;
    }

    public String getCheck() {
        return check;
    }

    public void setCheck(String check) {
        this.check = check;
    }

    public int getCount() {
        return count;
    }

    public void setCount(int count) {
        this.count = count;
    }

    public int getFee() {
        return fee;
    }

    public void setFee(int fee) {
        this.fee = fee;
    }

    public String getMem() {
        return mem;
    }

    public void setMem(String mem) {
        this.mem = mem;
    }

    public String getFname() {
        return fname;
    }

    public void setFname(String fname) {
        this.fname = fname;
    }

    public String getLname() {
        return lname;
    }

    public void setLname(String lname) {
        this.lname = lname;
    }

    public String getMedia() {
        return media;
    }

    public void setMedia(String media) {
        this.media = media;
    }

}
