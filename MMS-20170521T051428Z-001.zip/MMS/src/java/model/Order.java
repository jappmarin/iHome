/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

/**
 *
 * @author Asus
 */
public class Order extends Loanreturn {

    private int count = 0;
    Connection conn;

    public Order(Connection conn) {
        super(conn);
        this.conn = conn;
    }

    public void addOrder(String media_id, String mem_id) {
        try {
            Statement stmt = conn.createStatement();
            String sql = "SELECT media_id,media_name,Status_status_id FROM media_details where media_id = '" + media_id + "';";
            ResultSet rs = stmt.executeQuery(sql);
            rs.next();
            if (rs.getString("Status_status_id").equals("S01")) {
                Statement stmt_c = conn.createStatement();
                String c = "SELECT Member_mem_id FROM booking where Member_mem_id = '" + mem_id + "';";
                ResultSet rs_c = stmt_c.executeQuery(c);
                while (rs_c.next()) {
                    count += 1;
                }
                if (count < 3) {
                    int day = getDay_loan();
                    int month = getMonth_loan();
                    int year = getYear_loan();
                    String date = Integer.toString(year) + "-" + Integer.toString(month) + "-" + Integer.toString(day);
                    int day_b = day;
                    int month_b = month;
                    int year_b = year;
                    day_b += 3;
                    if (month_b == 1 || month_b == 3 || month_b == 5 || month_b == 7 || month_b == 8 || month_b == 10 || month_b == 12) {
                        if (day_b > 31) {
                            day_b -= 31;
                            month_b += 1;
                            if (month_b > 12) {
                                month_b -= 12;
                                year_b += 1;
                            }
                        }
                    } else {
                        if (day_b > 30) {
                            day_b -= 30;
                            month_b += 1;
                            if (month_b > 12) {
                                month_b -= 12;
                                year_b += 1;
                            }
                        }
                    }
                    String date_b = Integer.toString(year_b) + "-" + Integer.toString(month_b) + "-" + Integer.toString(day_b);
                    Statement stmt_a = conn.createStatement();
                    String sql_a = "INSERT INTO db_media.booking (booking_id, booking_day, recive_day, `Member_mem_id`) \n"
                            + "	VALUES ('B" + media_id + "', '" + date + "', '" + date_b + "', '" + mem_id + "');";
                    stmt_a.executeUpdate(sql_a);
                    Statement stmt_list = conn.createStatement();
                    String sql_l = "INSERT INTO db_media.list_booking (listbooking_id, `Booking_booking_id`, `Media_details_media_id`) \n"
                            + "	VALUES ('LB" + media_id + "', 'B" + media_id + "', '" + media_id + "');";
                    stmt_list.executeUpdate(sql_l);
                    sql_l = "UPDATE media_details SET Status_status_id = 'S04' WHERE media_id = '" + media_id + "';";
                    stmt_list.executeUpdate(sql_l);
                    setMem(rs.getString("media_name"));
                    setMedia(media_id);
                    setDay_loan(day);
                    setMonth_loan(month);
                    setYear_loan(year);
                    setSd_return(day_b);
                    setSm_return(month_b);
                    setSy_return(year_b);
                    setLname(date_b);
                    count += 1;
                    setCount(count);
                    setCheck("p");
                }

            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }

    public void showOrder(String mem_id) {
        try {
            Statement stmt = conn.createStatement();
            String sql = "SELECT media_id,media_name,booking_day,recive_day\n"
                    + "FROM booking b\n"
                    + "join member m \n"
                    + "on b.`Member_mem_id`=m.mem_id\n"
                    + "join list_booking lb\n"
                    + "on b.booking_id = lb.`Booking_booking_id`\n"
                    + "join media_details md\n"
                    + "on md.media_id = lb.`Media_details_media_id`\n"
                    + "where mem_id = '" + mem_id + "';";
            ResultSet rs = stmt.executeQuery(sql);
            while (rs.next()) {
                String[] date_b = rs.getString("booking_day").split("-");
                String[] date_r = rs.getString("recive_day").split("-");
                Loanreturn f = new Loanreturn();
                f.setMem(rs.getString("media_id"));
                f.setMedia(rs.getString("media_name"));
                f.setFname(date_b[2] + "/" + date_b[1] + "/" + date_b[0]);
                f.setLname(date_r[2] + "/" + date_r[1] + "/" + date_r[0]);
                fees.add(f);
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }

    public void cancleOrder(String media_id) {
        try {
            Statement stmt = conn.createStatement();
            String sql = "SELECT *\n"
                    + "FROM booking b\n"
                    + "join list_booking lb\n"
                    + "on b.booking_id = lb.`Booking_booking_id`\n"
                    + "join media_details m\n"
                    + "on lb.`Media_details_media_id`= m.media_id\n"
                    + "where m.media_id = '"+media_id+"';";
            ResultSet rs = stmt.executeQuery(sql);
            rs.next();
            String b = rs.getString("booking_id");
            String lb = rs.getString("listbooking_id");
            Statement stmt_d = conn.createStatement();
            String sql_d = "DELETE FROM db_media.list_booking WHERE listbooking_id = \"" + lb + "\";";
            stmt_d.executeUpdate(sql_d);
            sql_d = "DELETE FROM db_media.booking WHERE booking_id = \"" + b + "\";";
            stmt_d.executeUpdate(sql_d);
            sql_d = "UPDATE media_details\n"
                    + "SET Status_status_id = 'S01'\n"
                    + "WHERE media_id = \"" + media_id + "\" ;";
            stmt_d.executeUpdate(sql_d);
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }

    public void deleteOrder() {
        try {
            int day = getDay_loan();
            int month = getMonth_loan();
            int year = getYear_loan();
            Statement stmt = conn.createStatement();
            String sql = "SELECT *\n"
                    + "FROM booking b\n"
                    + "join list_booking lb\n"
                    + "on b.booking_id = lb.`Booking_booking_id`\n"
                    + "join media_details m\n"
                    + "on lb.`Media_details_media_id`=m.media_id;";
            ResultSet rs = stmt.executeQuery(sql);
            while (rs.next()) {
                String media_id = rs.getString("media_id");
                String b = rs.getString("booking_id");
                String lb = rs.getString("listbooking_id");
                String[] date_r = rs.getString("recive_day").split("-");
                int day_r = Integer.parseInt(date_r[2]);
                int month_r = Integer.parseInt(date_r[1]);
                int year_r = Integer.parseInt(date_r[0]);
                if (day < day_r) {
                    if (month < month_r) {
                        if (year > year_r) {
                            if (year - year_r == 1) {
                                month += 12;
                                if (month - month_r == 1) {
                                    if (month == 1 || month == 3 || month == 5 || month == 7 || month == 8 || month == 10 || month == 12) {
                                        day += 31;
                                    } else {
                                        day += 30;
                                    }
                                    if (day > day_r) {
                                        Statement stmt_d = conn.createStatement();
                                        String sql_d = "DELETE FROM db_media.list_booking WHERE listbooking_id = \"" + lb + "\";";
                                        stmt_d.executeUpdate(sql_d);
                                        sql_d = "DELETE FROM db_media.booking WHERE booking_id = \"" + b + "\";";
                                        stmt_d.executeUpdate(sql_d);
                                        sql_d = "UPDATE media_details\n"
                                                + "SET Status_status_id = 'S01'\n"
                                                + "WHERE media_id = \"" + media_id + "\" ;";
                                        stmt_d.executeUpdate(sql_d);
                                    }
                                }
                            }
                        }
                    } else if (month > month_r) {
                        if (month == 1 || month == 3 || month == 5 || month == 7 || month == 8 || month == 10 || month == 12) {
                            day += 31;
                        } else {
                            day += 30;
                        }
                        if (day > day_r) {
                            Statement stmt_d = conn.createStatement();
                            String sql_d = "DELETE FROM db_media.list_booking WHERE listbooking_id = \"" + lb + "\";";
                            stmt_d.executeUpdate(sql_d);
                            sql_d = "DELETE FROM db_media.booking WHERE booking_id = \"" + b + "\";";
                            stmt_d.executeUpdate(sql_d);
                            sql_d = "UPDATE media_details\n"
                                    + "SET Status_status_id = 'S01'\n"
                                    + "WHERE media_id = \"" + media_id + "\" ;";
                            stmt_d.executeUpdate(sql_d);
                        }
                    }
                } else if (day > day_r) {
                    Statement stmt_d = conn.createStatement();
                    String sql_d = "DELETE FROM db_media.list_booking WHERE listbooking_id = \"" + lb + "\";";
                    stmt_d.executeUpdate(sql_d);
                    sql_d = "DELETE FROM db_media.booking WHERE booking_id = \"" + b + "\";";
                    stmt_d.executeUpdate(sql_d);
                    sql_d = "UPDATE media_details\n"
                            + "SET Status_status_id = 'S01'\n"
                            + "WHERE media_id = \"" + media_id + "\" ;";
                    stmt_d.executeUpdate(sql_d);
                }
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }
}
