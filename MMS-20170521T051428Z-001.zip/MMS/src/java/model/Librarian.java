/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

/**
 *
 * @author Asus
 */
public class Librarian {
    private String libra_id;
    private String first_name;
    private String last_name;
    private String email;
    private String phone;
    private String work_field;
    
    Connection conn;

    public Librarian(Connection connection) {
        conn = connection;
    }

    public void addData(String username, String password) {
        try {
            Statement stmt = conn.createStatement();
            String sql = "SELECT * from librarian where first_name='" + username + "'";
            ResultSet rs = stmt.executeQuery(sql);
            if (rs.next()) {
                if (password.equals(rs.getString("libra_id"))) {
                    libra_id = (rs.getString("libra_id"));
                    first_name = (rs.getString("first_name"));
                    last_name = (rs.getString("last_name"));
                    email = (rs.getString("email"));
                    phone = (rs.getString("phone"));
                    work_field = (rs.getString("work_field"));
                }
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }

    }

    public String getLibra_id() {
        return libra_id;
    }

    public void setLibra_id(String libra_id) {
        this.libra_id = libra_id;
    }

    public String getFirst_name() {
        return first_name;
    }

    public void setFirst_name(String first_name) {
        this.first_name = first_name;
    }

    public String getLast_name() {
        return last_name;
    }

    public void setLast_name(String last_name) {
        this.last_name = last_name;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getWork_field() {
        return work_field;
    }

    public void setWork_field(String work_field) {
        this.work_field = work_field;
    }

    
    
    
}
