/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import model.Librarian;
import model.Student;
import model.Teacher;

/**
 *
 * @author Asus
 */
@WebServlet(name = "LoginServlet", urlPatterns = {"/LoginServlet"})
public class LoginServlet extends HttpServlet {

  
   

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    

    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        request.setCharacterEncoding("UTF-8");
        response.setCharacterEncoding("UTF-8");
        try (PrintWriter out = response.getWriter()) {
            String user = request.getParameter("user");
            String password = request.getParameter("password");
            int check;
            int nf;
            ServletContext ctx = getServletContext();
            Connection conn = (Connection) ctx.getAttribute("connection");
            HttpSession session = request.getSession();
            try {
                Statement stmt_m = conn.createStatement();
                Statement stmt_l = conn.createStatement();
                String sql_m = "SELECT * from member where first_name='" + user + "'";
                ResultSet rs_m = stmt_m.executeQuery(sql_m);
                String sql_l = "SELECT * from librarian where first_name='" + user + "'";
                ResultSet rs_l = stmt_l.executeQuery(sql_l);
                if (rs_m.next()) {
                    if (password.charAt(0) == '5' && password.equals(rs_m.getString("mem_id"))) {
                        Student student = new Student(conn);
                        student.addData(user, password);
                        student.addDatanew(user, password);
                        session.setAttribute("student", student);
                        check = 1;
                        session.setAttribute("check", check);
                        RequestDispatcher pg = request.getRequestDispatcher("indexmem.jsp");
                        pg.forward(request, response);
                    } else if (password.charAt(0) == '9' && password.equals(rs_m.getString("mem_id"))) {
                        Teacher teacher = new Teacher(conn);
                        teacher.addData(user, password);
                        teacher.addDatanew(user, password);
                        session.setAttribute("teacher", teacher);
                        check = 2;
                        session.setAttribute("check", check);
                        RequestDispatcher pg = request.getRequestDispatcher("indexmem.jsp");
                        pg.forward(request, response);
                    } else {
                        nf = 2;
                        request.setAttribute("nf", nf);
                        RequestDispatcher pg = request.getRequestDispatcher("landing.jsp");
                        pg.forward(request, response);
                    }

                } else if (rs_l.next()) {
                    if (password.charAt(0) == '1' && password.equals(rs_l.getString("libra_id"))) {
                        Librarian libra = new Librarian(conn);
                        libra.addData(user, password);
                        session.setAttribute("libra", libra);
                        check = 3;
                        session.setAttribute("check", check);
                        RequestDispatcher pg = request.getRequestDispatcher("indexlibra.jsp");
                        pg.forward(request, response);
                    } else {
                        nf = 2;
                        request.setAttribute("nf", nf);
                        RequestDispatcher pg = request.getRequestDispatcher("landing.jsp");
                        pg.forward(request, response);
                    }

                } else {
                    nf = 0;
                    request.setAttribute("nf", nf);
                    RequestDispatcher pg = request.getRequestDispatcher("landing.jsp");
                    pg.forward(request, response);
                }

            } catch (SQLException ex) {
                ex.printStackTrace();
            }

        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
